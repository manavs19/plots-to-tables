from finalPdfGen import FinalPdfGen
if __name__=="__main__":
	
	l = []
	d = [20,30,40,50,60,70]
	for i in range(500):
		l.append(d)

	for d in l:
		print d

	title = "title.jpg"
	xaxis = "xaxis.jpg"
	yaxis = "yaxis.jpg"
	data1 = "data1.png"
	data2 = "data2.png"
	data3 = "data3.png"
	data4 = "data4.png"
	data5 = "data5.png"
	data6 = "data6.png"
	dataset = [xaxis, data1,data2,data3,data4, data5]#, data6, data5, data6]

	# here new code begins


	gen = FinalPdfGen('team2.pdf', True)
	gen.add_table(title, yaxis, dataset, l)
	gen.add_table(title, yaxis, dataset, l)
	gen.print_file()

